# Cricket-Database-Management

This is a simple website designed for Cricket Database Management where the admins and users will be able to access differently. Admins will have the authority to perform CRUD Operations on many of the particulars in the website whereas the Users will only be able to view and get the information present in the page created or modified by the admins.


![Screenshot (166)](https://github.com/srujan3185/Cricket-Database-Management/assets/136983547/ff822765-9c7a-4e22-b258-d04fec1cd183)

![Screenshot (170)](https://github.com/srujan3185/Cricket-Database-Management/assets/136983547/367b85cf-2558-43a3-b80b-1c514d1bf17e)

![Screenshot (167)](https://github.com/srujan3185/Cricket-Database-Management/assets/136983547/95be5650-726e-4335-b574-7b072c93052e)

![Screenshot (168)](https://github.com/srujan3185/Cricket-Database-Management/assets/136983547/b948d224-7125-4b44-a53f-a3c4fc75077d)

![Screenshot (169)](https://github.com/srujan3185/Cricket-Database-Management/assets/136983547/16e45a3e-6041-48e8-8a6c-d822705386c1)

![Screenshot (171)](https://github.com/srujan3185/Cricket-Database-Management/assets/136983547/19438bf6-edb5-45ba-9b49-d50f87c123b8)
